# Pulp Terror — Free 10-Plate Teaser

You're holding 10 restored pulp horror illustrations from the 1920s and 1930s — monsters, ghosts, skeletons, and weird-menace villains from the golden age of the pulp magazines.

These are genuine antiques: pulp magazine covers and interior illustrations, cleaned and restored (paper tone evened, yellowing reduced, linework sharpened). Restored, not AI.

**The full pack** — *Pulp Terror: 100 Restored Vintage Horror Illustrations* — has 90 more plates, a themed PDF index, and a provenance CSV documenting the public-domain basis of every single plate.

- **Personal ($16):** print for your walls, journals, Halloween decor, gifts.
- **Commercial ($59):** everything in Personal, plus book covers, merch, tattoo flash, client work. Up to 500 physical end-products per design.

All artwork is verified public domain (pre-1931 publication, or 1931–1934 with documented copyright non-renewal). You're buying the restoration and curation — the organized, documented pack — not the underlying images, which belong to everyone.

This is a descriptive collection and is not affiliated with or endorsed by any magazine or publisher.
