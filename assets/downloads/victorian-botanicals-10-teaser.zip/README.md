# Victorian Botanicals — Free 10-Plate Teaser
*Gilt & Grotesque*

Ten genuine Victorian botanical plates, cleaned and restored — a preview of the full **Victorian Botanicals: 120 Restored Plates** pack.

## What's inside
- 10 restored high-resolution JPGs (same restoration as the paid pack: paper tone evened, yellowing reduced, tones balanced, linework lightly sharpened)
- This README + a Personal-use license note

## License — Personal use
Use these plates for your own walls, junk journal, scrapbook, phone wallpaper, and gifts. Not for products you sell, not for client work. Want to sell things made with these? The full 120-plate pack comes with a Commercial license option ($59, up to 500 physical end-products per design).

## About the art
Every plate is a genuine antique botanical illustration from the 1800s. All artwork is verified public domain (published 1930 or earlier, or released under CC0). You're downloading the restored files — the underlying images belong to everyone.

Note: four of these teaser plates (T01, T02, T03, T10) also appear in the paid 120-plate pack. This is a true preview, not a separate set.

*Restored, not AI.*
