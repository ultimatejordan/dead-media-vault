# Ukiyo-e — Free 10-Print Teaser
*Gilt & Grotesque*

Ten genuine Japanese woodblock prints, cleaned and restored — a preview of the full **Ukiyo-e: 100 Japanese Woodblock Prints, Restored** pack.

## What's inside
- 10 restored high-resolution JPGs (same restoration as the paid pack: paper tone evened, fading reduced without killing the original palette, tones balanced, key lines lightly sharpened)
- This README + a Personal-use license note

## License — Personal use
Use these prints for your own walls, junk journal, scrapbook, phone wallpaper, and gifts. Not for products you sell, not for client work. Want to sell things made with these? The full 100-print pack comes with a Commercial license option ($59, up to 500 physical end-products per design).

## About the prints
Every print is a genuine antique woodblock (Edo period through early 1900s); every artist in the pack died before 1930. All artwork is verified public domain, checked print by print at the license-template level. You're downloading the restored files — the underlying prints belong to everyone.

Note: at least four of these teaser prints (including the wave) also appear in the paid 100-print pack. This is a true preview, not a separate set.

*Restored, not AI.*
